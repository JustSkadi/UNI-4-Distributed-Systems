package com.example.restservice.exception;
import com.example.restservice.exception.PersonNotFoundException;
import com.example.restservice.exception.ConflictEx;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@ControllerAdvice
@RestControllerAdvice
public class FaultController {

    @ExceptionHandler(PersonNotFoundException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity<?> handlePersonNotFound(PersonNotFoundException ex) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PROBLEM_JSON_VALUE)
                .body(Map.of(
                        "title", "NOT_FOUND",
                        "status", 404,
                        "detail", "The person of ID=" + ex.getMessage() + " DOES NOT EXIST"
                ));
    }

    @ExceptionHandler(ConflictEx.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.CONFLICT)
    public ResponseEntity<?> handleConflict(ConflictEx ex) {
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PROBLEM_JSON_VALUE)
                .body(Map.of(
                        "title", "CONFLICT",
                        "status", 409,
                        "detail", ex.getMessage()
                ));
    }

    @ExceptionHandler(BadRequestEx.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<?> handleBadRequest(BadRequestEx ex) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PROBLEM_JSON_VALUE)
                .body(Map.of(
                        "title", "BAD_REQUEST",
                        "status", 400,
                        "detail", ex.getMessage()
                ));
    }
}
