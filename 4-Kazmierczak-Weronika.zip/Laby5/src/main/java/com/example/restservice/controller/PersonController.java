package com.example.restservice.controller;
import com.example.restservice.model.Person;
import com.example.restservice.model.PersonStatus;
import com.example.restservice.repository.PersonRepository;
import com.example.restservice.exception.ConflictEx;
import com.example.restservice.exception.PersonNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class PersonController {

    private final PersonRepository dataRepo;

    public PersonController(PersonRepository dataRepo) {
        this.dataRepo = dataRepo;
    }

    @GetMapping("/persons")
    public CollectionModel<EntityModel<Person>> getAllPersons() {
        List<EntityModel<Person>> persons =
                dataRepo.getAllPersons().stream()
                        .map(person ->
                                EntityModel.of(person,
                                        linkTo(methodOn(PersonController.class).getPerson(person.getId())).withSelfRel(),
                                        linkTo(methodOn(PersonController.class).deletePerson(person.getId())).withRel("delete"),
                                        linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
                                )
                        ).collect(Collectors.toList());

        return CollectionModel.of(persons,
                linkTo(methodOn(PersonController.class).getAllPersons()).withSelfRel());
    }

    @GetMapping("/persons/{id}")
    public EntityModel<Person> getPerson(@PathVariable int id) {
        Person person = dataRepo.getPerson(id);

        EntityModel<Person> personModel = EntityModel.of(person);

        // Sprawdź bieżący status osoby i odpowiednio dodaj linki
        if (person.getStatus() == PersonStatus.ACTIVE) {
            personModel.add(
                    linkTo(methodOn(PersonController.class).hirePerson(id)).withRel("hire"),
                    linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete")
            );
        } else if (person.getStatus() == PersonStatus.HIRED) {
            personModel.add(
                    linkTo(methodOn(PersonController.class).vacatePerson(id)).withRel("vacate"),
                    linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete")
            );
        }

        personModel.add(
                linkTo(methodOn(PersonController.class).getPerson(id)).withSelfRel(),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return personModel;
    }

    @PatchMapping("/persons/{id}/activate")
    public ResponseEntity<?> activatePerson(@PathVariable int id) {
        Person person = dataRepo.getPerson(id);

        if (person.getStatus() != PersonStatus.NOT_ACTIVE) {
            throw new ConflictEx("You CAN'T activate a person with status " + person.getStatus());
        }

        person.setStatus(PersonStatus.ACTIVE);

        EntityModel<Person> personModel = EntityModel.of(person,
                linkTo(methodOn(PersonController.class).getPerson(id)).withSelfRel(),
                linkTo(methodOn(PersonController.class).hirePerson(id)).withRel("hire"),
                linkTo(methodOn(PersonController.class).deactivatePerson(id)).withRel("deactivate"),
                linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete"),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return ResponseEntity.ok(personModel);
    }

    @PatchMapping("/persons/{id}/deactivate")
    public ResponseEntity<?> deactivatePerson(@PathVariable int id) {
        Person person = dataRepo.getPerson(id);

        if (person.getStatus() == PersonStatus.NOT_ACTIVE) {
            throw new ConflictEx("Person is already deactivated");
        }

        if (person.getStatus() == PersonStatus.HIRED) {
            throw new ConflictEx("You CAN'T deactivate a person with status HIRED. Vacate the person first.");
        }

        person.setStatus(PersonStatus.NOT_ACTIVE);

        EntityModel<Person> personModel = EntityModel.of(person,
                linkTo(methodOn(PersonController.class).getPerson(id)).withSelfRel(),
                linkTo(methodOn(PersonController.class).activatePerson(id)).withRel("activate"),
                linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete"),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return ResponseEntity.ok(personModel);
    }

    @PostMapping("/persons")
    public ResponseEntity<EntityModel<Person>> addPerson(@RequestBody Person person) {
        Person savedPerson = dataRepo.addPerson(person);

        EntityModel<Person> personModel = EntityModel.of(savedPerson,
                linkTo(methodOn(PersonController.class).getPerson(savedPerson.getId())).withSelfRel(),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return ResponseEntity
                .created(linkTo(methodOn(PersonController.class).getPerson(savedPerson.getId())).toUri())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .body(personModel);
    }

    @DeleteMapping("/persons/{id}")
    public ResponseEntity<?> deletePerson(@PathVariable int id) {
        dataRepo.deletePerson(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/persons/{id}/hire")
    public ResponseEntity<?> hirePerson(@PathVariable int id) {
        Person person = dataRepo.getPerson(id);

        if (person.getStatus() != PersonStatus.ACTIVE) {
            throw new ConflictEx("You CAN'T hire a person with status " + person.getStatus());
        }

        person.setStatus(PersonStatus.HIRED);

        EntityModel<Person> personModel = EntityModel.of(person,
                linkTo(methodOn(PersonController.class).getPerson(id)).withSelfRel(),
                linkTo(methodOn(PersonController.class).vacatePerson(id)).withRel("vacate"),
                linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete"),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return ResponseEntity.ok(personModel);
    }

    @PatchMapping("/persons/{id}/vacate")
    public ResponseEntity<?> vacatePerson(@PathVariable int id) {
        Person person = dataRepo.getPerson(id);

        if (person.getStatus() != PersonStatus.HIRED) {
            throw new ConflictEx("You CAN'T vacate a person with status " + person.getStatus());
        }

        person.setStatus(PersonStatus.ACTIVE);

        EntityModel<Person> personModel = EntityModel.of(person,
                linkTo(methodOn(PersonController.class).getPerson(id)).withSelfRel(),
                linkTo(methodOn(PersonController.class).hirePerson(id)).withRel("hire"),
                linkTo(methodOn(PersonController.class).deletePerson(id)).withRel("delete"),
                linkTo(methodOn(PersonController.class).getAllPersons()).withRel("list_all")
        );

        return ResponseEntity.ok(personModel);
    }
}
