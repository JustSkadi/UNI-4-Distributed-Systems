package com.example.restservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.CONFLICT)
public class PersonExistsException extends RuntimeException {
  public PersonExistsException(int id) {
    super("Person with ID " + id + " already exists");
  }

  public PersonExistsException(String message) {
    super(message);
  }
}