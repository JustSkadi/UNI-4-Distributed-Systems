package com.example.restservice.repository;

import com.example.restservice.exception.BadRequestEx;
import com.example.restservice.exception.PersonExistsException;
import com.example.restservice.exception.PersonNotFoundException;
import com.example.restservice.model.Person;
import com.example.restservice.model.PersonStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class PersonRepositoryImpl implements PersonRepository {

    private List<Person> personList;

    public PersonRepositoryImpl() {
        personList = new ArrayList<>();
        // Dodaj kilka początkowych osób do testów
        personList.add(new Person(1, "Jan Kowalski", 25));
        personList.add(new Person(2, "Anna Nowak", 30));
    }

    @Override
    public List<Person> getAllPersons() {
        return personList;
    }

    @Override
    public Person getPerson(int id) throws PersonNotFoundException {
        for (Person thePerson : personList) {
            if (thePerson.getId() == id) {
                return thePerson;
            }
        }
        throw new PersonNotFoundException(id);
    }

    @Override
    public Person addPerson(Person person) throws BadRequestEx, PersonExistsException {
        // Walidacja danych
        if (person.getName() == null || person.getName().trim().isEmpty()) {
            throw new BadRequestEx("Name is required");
        }
        if (person.getAge() <= 0) {
            throw new BadRequestEx("Age must be a positive number");
        }
        if (person.getId() <= 0) {
            throw new BadRequestEx("ID must be a positive number");
        }

        // Sprawdzenie, czy osoba o podanym ID już istnieje
        for (Person existingPerson : personList) {
            if (existingPerson.getId() == person.getId()) {
                throw new PersonExistsException(person.getId());
            }
        }

        // Ustawienie domyślnego statusu ACTIVE, jeśli nie podano
        if (person.getStatus() == null) {
            person.setStatus(PersonStatus.ACTIVE);
        }

        personList.add(person);
        return person;
    }

    @Override
    public boolean deletePerson(int id) throws PersonNotFoundException {
        for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {
            Person person = iterator.next();
            if (person.getId() == id) {
                iterator.remove();
                return true;
            }
        }
        throw new PersonNotFoundException(id);
    }
}