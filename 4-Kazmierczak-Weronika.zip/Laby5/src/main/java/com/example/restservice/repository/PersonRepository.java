package com.example.restservice.repository;
import com.example.restservice.model.Person;
import com.example.restservice.exception.PersonNotFoundException;
import com.example.restservice.exception.BadRequestEx;

import java.util.List;

public interface PersonRepository {
    List<Person> getAllPersons();
    Person getPerson(int id) throws PersonNotFoundException;
    Person addPerson(Person person) throws BadRequestEx;
    boolean deletePerson(int id) throws PersonNotFoundException;
}
