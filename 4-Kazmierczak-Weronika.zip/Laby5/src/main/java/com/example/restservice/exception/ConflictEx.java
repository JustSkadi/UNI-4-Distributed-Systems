package com.example.restservice.exception;

public class ConflictEx extends RuntimeException {
    public ConflictEx(String message) {
        super(message);
    }
}