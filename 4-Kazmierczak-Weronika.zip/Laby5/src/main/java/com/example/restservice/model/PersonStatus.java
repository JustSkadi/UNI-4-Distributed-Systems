package com.example.restservice.model;

public enum PersonStatus {
    NOT_ACTIVE,
    ACTIVE,
    HIRED
}
