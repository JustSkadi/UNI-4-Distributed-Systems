package com.example.restservice.laby5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Laby5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
