package com.example.grpc.grpcserver;

import com.example.grpc.grpcinterface.Record;
import com.example.grpc.grpcinterface.RecordRequest;
import java.io.InputStream;
import com.example.grpc.grpcinterface.RecordList;
import com.example.grpc.grpcinterface.EmptyRequest;
import com.example.grpc.grpcinterface.OperationResponse;
import com.example.grpc.grpcinterface.SearchRequest;
import com.example.grpc.grpcinterface.SearchResponse;
import com.example.grpc.grpcinterface.ImageRequest;
import com.example.grpc.grpcinterface.ImageChunk;
import com.example.grpc.grpcinterface.RecordServiceGrpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

public class GrpcServer {
    private final int port = 50051;
    private Server server;

    public static void main(String[] args) throws IOException, InterruptedException {
        GrpcServer server = new GrpcServer();
        server.start();
        server.blockUntilShutdown();
    }

    private void start() throws IOException {
        server = ServerBuilder.forPort(port)
                .addService(new RecordServiceImpl())
                .build()
                .start();
        System.out.println("Server started on port " + port);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down server due to JVM shutdown");
            GrpcServer.this.stop();
        }));
    }

    private void stop() {
        if (server != null) {
            server.shutdown();
        }
    }

    private void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }

    static class RecordServiceImpl extends RecordServiceGrpc.RecordServiceImplBase {
        private final ConcurrentMap<Integer, Record> records = new ConcurrentHashMap<>();
        private int nextId = 1;
        private static final String SERVER_IMAGES_DIR = "images/";
        private static final int BUFFER_SIZE = 4096;

        @Override
        public void addRecord(Record request, StreamObserver<OperationResponse> responseObserver) {
            System.out.println("Adding record...");
            Record recordToAdd = request.toBuilder().setId(nextId++).build();
            records.put(recordToAdd.getId(), recordToAdd);

            OperationResponse response = OperationResponse.newBuilder()
                    .setSuccess(true)
                    .setMessage("Record added with ID: " + recordToAdd.getId())
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
            System.out.println("Record added successfully");
        }

        @Override
        public void getRecord(RecordRequest request, StreamObserver<Record> responseObserver) {
            System.out.println("Getting record with ID: " + request.getId());
            Record record = records.get(request.getId());

            if (record != null) {
                responseObserver.onNext(record);
            } else {
                responseObserver.onNext(Record.newBuilder().setId(-1).build());
            }

            responseObserver.onCompleted();
            System.out.println("Get record completed");
        }

        @Override
        public void getAllRecords(EmptyRequest request, StreamObserver<RecordList> responseObserver) {
            System.out.println("Getting all records...");
            List<Record> recordList = new ArrayList<>(records.values());

            RecordList response = RecordList.newBuilder()
                    .addAllRecords(recordList)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
            System.out.println("Get all records completed");
        }

        @Override
        public void searchRecords(SearchRequest request, StreamObserver<SearchResponse> responseObserver) {
            System.out.println("Searching records with criteria: " + request.getField() + " = " + request.getValue());

            new Thread(() -> {
                try {
                    Thread.sleep(3000);

                    List<Record> matchingRecords = new ArrayList<>();
                    switch (request.getField()) {
                        case "name":
                            matchingRecords = records.values().stream()
                                    .filter(r -> r.getName().contains(request.getValue()))
                                    .collect(Collectors.toList());
                            break;
                        case "category":
                            matchingRecords = records.values().stream()
                                    .filter(r -> r.getCategory().contains(request.getValue()))
                                    .collect(Collectors.toList());
                            break;
                    }

                    SearchResponse response = SearchResponse.newBuilder()
                            .setCount(matchingRecords.size())
                            .addAllMatchingRecords(matchingRecords)
                            .build();

                    responseObserver.onNext(response);
                    responseObserver.onCompleted();
                    System.out.println("Search completed with " + matchingRecords.size() + " results");

                } catch (InterruptedException e) {
                    responseObserver.onError(e);
                }
            }).start();

            System.out.println("Search request accepted, processing asynchronously...");
        }

        @Override
        public void streamImageFromServer(ImageRequest request, StreamObserver<ImageChunk> responseObserver) {
            String imageName = request.getImageName();
            System.out.println("Streaming image: " + imageName);

            try {
                InputStream inputStream = getClass().getClassLoader().getResourceAsStream(SERVER_IMAGES_DIR + imageName);

                if (inputStream == null) {
                    System.out.println("Image not found: " + SERVER_IMAGES_DIR + imageName);
                    responseObserver.onError(new IOException("Image not found: " + imageName));
                    return;
                }

                System.out.println("Image found, beginning streaming");

                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesRead;
                int totalSent = 0;

                try {
                    while ((bytesRead = inputStream.read(buffer)) > 0) {
                        ImageChunk chunk = ImageChunk.newBuilder()
                                .setChunk(com.google.protobuf.ByteString.copyFrom(buffer, 0, bytesRead))
                                .setSize(bytesRead)
                                .build();

                        responseObserver.onNext(chunk);
                        totalSent += bytesRead;
                        System.out.println("Sent chunk of size: " + bytesRead + ", total: " + totalSent);

                        // Reduced sleep time or remove entirely for testing
                        Thread.sleep(100); // Reduced from 500ms to 100ms
                    }

                    inputStream.close();
                    System.out.println("Image streaming completed, total bytes: " + totalSent);
                    responseObserver.onCompleted(); // Make sure this is called

                } catch (Exception e) {
                    System.out.println("Error during streaming: " + e.getMessage());
                    e.printStackTrace();
                    responseObserver.onError(e);
                }
            } catch (Exception e) {
                System.out.println("Exception in streamImageFromServer: " + e.getMessage());
                e.printStackTrace();
                responseObserver.onError(e);
            }
        }
    }
}
