package com.example.grpc.grpcclient;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import com.example.grpc.grpcinterface.Record;
import com.example.grpc.grpcinterface.RecordRequest;
import com.example.grpc.grpcinterface.RecordList;
import com.example.grpc.grpcinterface.EmptyRequest;
import com.example.grpc.grpcinterface.SearchRequest;
import com.example.grpc.grpcinterface.SearchResponse;
import com.example.grpc.grpcinterface.OperationResponse;
import com.example.grpc.grpcinterface.ImageRequest;
import com.example.grpc.grpcinterface.ImageChunk;
import com.example.grpc.grpcinterface.RecordServiceGrpc;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class GrpcClient {
    private final ManagedChannel channel;
    private final RecordServiceGrpc.RecordServiceBlockingStub blockingStub;
    private final RecordServiceGrpc.RecordServiceStub asyncStub;
    private static final String CLIENT_IMAGES_DIR = "client/images/";

    public GrpcClient(String host, int port) {
        this.channel = ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext()
                .build();
        this.blockingStub = RecordServiceGrpc.newBlockingStub(channel);
        this.asyncStub = RecordServiceGrpc.newStub(channel);
    }

    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

    public static void main(String[] args) throws InterruptedException {
        GrpcClient client = new GrpcClient("localhost", 50051);
        try {
            client.runMenu();
        } finally {
            client.shutdown();
        }
    }

    private void runMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        File dir = new File(CLIENT_IMAGES_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        while (running) {
            printMenu();
            int choice;

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    addRecord(scanner);
                    break;
                case 2:
                    getRecord(scanner);
                    break;
                case 3:
                    getAllRecords();
                    break;
                case 4:
                    searchRecords(scanner);
                    break;
                case 5:
                    downloadImage(scanner);
                    break;
                case 0:
                    running = false;
                    System.out.println("Exiting client...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private void printMenu() {
        System.out.println("\n----- gRPC Client Menu -----");
        System.out.println("1. Add Record");
        System.out.println("2. Get Record by ID");
        System.out.println("3. Get All Records");
        System.out.println("4. Search Records (Async)");
        System.out.println("5. Download Image");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private void addRecord(Scanner scanner) {
        System.out.println("\n----- Add Record -----");

        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter age: ");
        int age = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter category: ");
        String category = scanner.nextLine();

        System.out.print("Enter weight: ");
        double weight = Double.parseDouble(scanner.nextLine());

        System.out.print("Enter image name (leave empty if none): ");
        String imageName = scanner.nextLine();

        Record record = Record.newBuilder()
                .setName(name)
                .setAge(age)
                .setCategory(category)
                .setWeight(weight)
                .setImageName(imageName)
                .build();

        OperationResponse response = blockingStub.addRecord(record);
        System.out.println("Response: " + response.getMessage());
    }

    private void getRecord(Scanner scanner) {
        System.out.println("\n----- Get Record -----");
        System.out.print("Enter record ID: ");
        int id = Integer.parseInt(scanner.nextLine());

        RecordRequest request = RecordRequest.newBuilder().setId(id).build();
        Record record = blockingStub.getRecord(request);

        if (record.getId() == -1) {
            System.out.println("Record not found.");
        } else {
            System.out.println("Record found:");
            printRecord(record);
        }
    }

    private void getAllRecords() {
        System.out.println("\n----- All Records -----");
        RecordList recordList = blockingStub.getAllRecords(EmptyRequest.newBuilder().build());

        if (recordList.getRecordsCount() == 0) {
            System.out.println("No records found.");
        } else {
            System.out.println("Found " + recordList.getRecordsCount() + " records:");
            for (Record record : recordList.getRecordsList()) {
                printRecord(record);
                System.out.println("---------------");
            }
        }
    }

    private void printRecord(Record record) {
        System.out.println("ID: " + record.getId());
        System.out.println("Name: " + record.getName());
        System.out.println("Age: " + record.getAge());
        System.out.println("Category: " + record.getCategory());
        System.out.println("Weight: " + record.getWeight());
        System.out.println("Image: " + (record.getImageName().isEmpty() ? "None" : record.getImageName()));
    }

    private void searchRecords(Scanner scanner) {
        System.out.println("\n----- Search Records (Async) -----");
        System.out.print("Enter field to search (name, category): ");
        String field = scanner.nextLine();

        System.out.print("Enter value to search for: ");
        String value = scanner.nextLine();

        SearchRequest request = SearchRequest.newBuilder()
                .setField(field)
                .setValue(value)
                .build();

        System.out.println("Sending async search request...");
        final CountDownLatch finishLatch = new CountDownLatch(1);

        asyncStub.searchRecords(request, new StreamObserver<SearchResponse>() {
            @Override
            public void onNext(SearchResponse response) {
                System.out.println("\nSearch completed! Found " + response.getCount() + " matches:");
                for (Record record : response.getMatchingRecordsList()) {
                    printRecord(record);
                    System.out.println("---------------");
                }
            }

            @Override
            public void onError(Throwable t) {
                System.out.println("Search failed: " + t.getMessage());
                finishLatch.countDown();
            }

            @Override
            public void onCompleted() {
                System.out.println("Search operation finished.");
                finishLatch.countDown();
            }
        });

        System.out.println("Async search request sent. You can continue using the client while waiting for results.");
        System.out.println("(Results will appear when ready)");
    }

    private void downloadImage(Scanner scanner) {
        System.out.println("\n----- Download Image -----");
        System.out.print("Enter image name to download: ");
        String imageName = scanner.nextLine();

        ImageRequest request = ImageRequest.newBuilder()
                .setImageName(imageName)
                .build();

        System.out.println("Starting image download...");

        System.out.println("Using synchronous streaming:");
        try {
            Iterator<ImageChunk> imageChunks = blockingStub.streamImageFromServer(request);
            String outputPath = CLIENT_IMAGES_DIR + imageName;

            try (FileOutputStream outputStream = new FileOutputStream(outputPath)) {
                int chunkCount = 0;

                while (imageChunks.hasNext()) {
                    ImageChunk chunk = imageChunks.next();
                    outputStream.write(chunk.getChunk().toByteArray());
                    chunkCount++;
                    System.out.print("*"); // Show progress
                }

                System.out.println("\nImage downloaded successfully in " + chunkCount + " chunks.");
                System.out.println("Saved to: " + outputPath);
            }
        } catch (Exception e) {
            System.out.println("\nError downloading image: " + e.getMessage());
        }

        System.out.println("\nAlso trying asynchronous streaming:");
        final CountDownLatch finishLatch = new CountDownLatch(1);

        try {
            String asyncOutputPath = CLIENT_IMAGES_DIR + "async_" + imageName;
            FileOutputStream asyncOutputStream = new FileOutputStream(asyncOutputPath);
            ImageChunkObserver observer = new ImageChunkObserver(asyncOutputStream, asyncOutputPath, finishLatch);
            asyncStub.streamImageFromServer(request, observer);

            System.out.println("Async download request sent. You can continue using the client.");
            System.out.println("(Progress indicators will appear as chunks arrive)");

        } catch (Exception e) {
            System.out.println("\nError setting up async download: " + e.getMessage());
            finishLatch.countDown();
        }
    }

    private static class ImageChunkObserver implements StreamObserver<ImageChunk> {
        private final FileOutputStream outputStream;
        private final String outputPath;
        private final CountDownLatch finishLatch;
        private int chunkCount = 0;

        public ImageChunkObserver(FileOutputStream outputStream, String outputPath, CountDownLatch finishLatch) {
            this.outputStream = outputStream;
            this.outputPath = outputPath;
            this.finishLatch = finishLatch;
        }

        @Override
        public void onNext(ImageChunk chunk) {
            try {
                outputStream.write(chunk.getChunk().toByteArray());
                chunkCount++;
                System.out.print("*"); // Show progress
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onError(Throwable t) {
            System.out.println("\nAsync download failed: " + t.getMessage());
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            finishLatch.countDown();
        }

        @Override
        public void onCompleted() {
            try {
                outputStream.close();
                System.out.println("\nAsync download completed in " + chunkCount + " chunks!");
                System.out.println("Saved to: " + outputPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
            finishLatch.countDown();
        }
    }
}