package com.example.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;

public class Consumer {
    private final static String QUEUE_NAME = "hello";

    public static void main(String[] args) throws Exception {
        // Utworzenie połączenia i kanału do komunikacji
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // Deklaracja kolejki dla komunikacji
        channel.queueDeclare(QUEUE_NAME, false, false, false, null);

        // Utworzenie konsumenta
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {
                String message = new String(body, "UTF-8");
                System.out.println("Odebrano: " + message);
            }
        };

        // Podłączenie/rejestracja konsumenta do kolejki
        channel.basicConsume(QUEUE_NAME, true, consumer);

        System.out.println("Konsument gotowy do odbierania wiadomości. Naciśnij Enter, aby zakończyć.");
        System.in.read();

        // Zamknięcie kanału i połączenia
        channel.close();
        connection.close();
    }
}