package com.example.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class RPCClient implements AutoCloseable {
    private final Connection connection;
    private final Channel channel;
    private final String requestQueueName = "rpc_queue";

    public RPCClient() throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        connection = factory.newConnection();
        channel = connection.createChannel();
    }

    public String call(String message) throws IOException, InterruptedException, ExecutionException {
        final String corrId = UUID.randomUUID().toString();
        final String replyQueueName = channel.queueDeclare().getQueue();

        AMQP.BasicProperties props = new AMQP.BasicProperties.Builder()
                .correlationId(corrId)
                .replyTo(replyQueueName)
                .build();

        channel.basicPublish("", requestQueueName, props, message.getBytes("UTF-8"));

        final CompletableFuture<String> response = new CompletableFuture<>();

        String ctag = channel.basicConsume(replyQueueName, true, (consumerTag, delivery) -> {
            if (delivery.getProperties().getCorrelationId().equals(corrId)) {
                response.complete(new String(delivery.getBody(), "UTF-8"));
            }
        }, consumerTag -> {});

        String result = response.get(); // Teraz obsługujemy ExecutionException w sygnaturze metody
        channel.basicCancel(ctag);
        return result;
    }

    @Override
    public void close() throws IOException, TimeoutException {
        channel.close();
        connection.close();
    }

    public static void main(String[] args) {
        try (RPCClient rpcClient = new RPCClient()) {
            System.out.println("RPC Client gotowy. Wysyłanie żądania...");

            // Przykładowe wywołanie - konwersja tekstu na liczbę i obliczenie kwadratu
            String request = "10";  // Wyślij liczbę 10 do serwera
            System.out.println("Wysyłam żądanie obliczenia kwadratu liczby: " + request);

            String response = rpcClient.call(request);
            System.out.println("Odpowiedź: " + response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}