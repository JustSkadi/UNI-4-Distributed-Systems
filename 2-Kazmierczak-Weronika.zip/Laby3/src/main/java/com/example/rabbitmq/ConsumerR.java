package com.example.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;

public class ConsumerR {
    private final static String EXCHANGE_NAME = "direct_logs";

    public static void main(String[] args) throws Exception {
        // Pobierz klucze routingu z argumentów lub użyj domyślnych
        String[] routingKeys = args.length > 0 ? args : new String[]{"info"};

        // Utworzenie połączenia i kanału do komunikacji
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // Deklaracja exchange typu direct
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.DIRECT);

        // Utworzenie tymczasowej kolejki z losową nazwą
        String queueName = channel.queueDeclare().getQueue();

        // Powiązanie kolejki z exchange dla każdego klucza routingu
        for (String routingKey : routingKeys) {
            channel.queueBind(queueName, EXCHANGE_NAME, routingKey);
            System.out.println("Nasłuchiwanie wiadomości z kluczem routingu: " + routingKey);
        }

        // Utworzenie konsumenta
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {
                String message = new String(body, "UTF-8");
                String routingKey = envelope.getRoutingKey();
                System.out.println("Odebrano [" + routingKey + "]: " + message);
            }
        };

        // Podłączenie/rejestracja konsumenta do kolejki
        channel.basicConsume(queueName, true, consumer);

        System.out.println("Konsument gotowy do odbierania wiadomości. Naciśnij Enter, aby zakończyć.");
        System.in.read();

        // Zamknięcie kanału i połączenia
        channel.close();
        connection.close();
    }
}