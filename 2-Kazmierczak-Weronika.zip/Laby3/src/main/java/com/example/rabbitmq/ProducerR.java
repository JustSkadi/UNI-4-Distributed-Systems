package com.example.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class ProducerR {
    private final static String EXCHANGE_NAME = "direct_logs";

    public static void main(String[] args) throws Exception {
        // Utworzenie połączenia i kanału do komunikacji
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // Deklaracja exchange typu direct
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.DIRECT);

        // Wysyłanie wiadomości z różnymi kluczami routingu
        String[] routingKeys = {"info", "alert", "news"};

        for (int i = 0; i < 15; i++) {
            String routingKey = routingKeys[i % routingKeys.length];
            String message = routingKey + " wiadomość #" + i;

            channel.basicPublish(EXCHANGE_NAME, routingKey, null, message.getBytes());
            System.out.println("Wysłano [" + routingKey + "]: " + message);
            Thread.sleep(500);
        }

        // Zamknięcie kanału i połączenia
        channel.close();
        connection.close();
    }
}