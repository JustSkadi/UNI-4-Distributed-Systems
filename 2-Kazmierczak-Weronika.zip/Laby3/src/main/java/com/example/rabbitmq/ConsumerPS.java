package com.example.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;

public class ConsumerPS {
    private final static String EXCHANGE_NAME = "logs";

    public static void main(String[] args) throws Exception {
        // Utworzenie połączenia i kanału do komunikacji
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // Deklaracja exchange typu fanout
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.FANOUT);

        // Utworzenie tymczasowej kolejki z losową nazwą
        String queueName = channel.queueDeclare().getQueue();

        // Powiązanie kolejki z exchange
        channel.queueBind(queueName, EXCHANGE_NAME, "");

        System.out.println("Oczekiwanie na wiadomości. ID kolejki: " + queueName);

        // Utworzenie konsumenta
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {
                String message = new String(body, "UTF-8");
                System.out.println("Odebrano: " + message);
            }
        };

        // Podłączenie/rejestracja konsumenta do kolejki
        channel.basicConsume(queueName, true, consumer);

        System.out.println("Konsument gotowy do odbierania wiadomości. Naciśnij Enter, aby zakończyć.");
        System.in.read();

        // Zamknięcie kanału i połączenia
        channel.close();
        connection.close();
    }
}