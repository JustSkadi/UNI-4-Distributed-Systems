package com.example.rabbitmq;
import com.rabbitmq.client.*;
import java.io.IOException;

public class RPCServer {
    private static final String RPC_QUEUE_NAME = "rpc_queue";

    private static int square(int n) {
        return n * n;
    }

    public static void main(String[] args) throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.queueDeclare(RPC_QUEUE_NAME, false, false, false, null);
        channel.basicQos(1);  // Obsługuj tylko jedną wiadomość naraz

        System.out.println("Serwer RPC gotowy. Oczekiwanie na żądania...");

        // Utworzenie konsumenta
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {
                // Pobierz dane z żądania
                String message = new String(body, "UTF-8");
                System.out.println("Otrzymano żądanie: " + message);

                // Konwersja na int
                int n = Integer.parseInt(message);

                // Obliczenie wyniku
                int result = square(n);

                // Przygotowanie odpowiedzi
                String response = String.valueOf(result);

                // Przygotowanie właściwości odpowiedzi
                AMQP.BasicProperties replyProps = new AMQP.BasicProperties.Builder()
                        .correlationId(properties.getCorrelationId())
                        .build();

                // Wysłanie odpowiedzi
                channel.basicPublish("", properties.getReplyTo(), replyProps,
                        response.getBytes("UTF-8"));

                // Potwierdzenie przetworzenia żądania
                channel.basicAck(envelope.getDeliveryTag(), false);

                System.out.println("Wysłano odpowiedź: " + response);
            }
        };

        // Zarejestrowanie konsumenta
        channel.basicConsume(RPC_QUEUE_NAME, false, consumer);

        // Serwer działa w nieskończoność, czekając na żądania
        System.out.println("Naciśnij CTRL+C, aby zakończyć.");
        Thread.currentThread().join();
    }
}