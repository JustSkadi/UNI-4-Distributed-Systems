package com.example.rabbitmq;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class Producer {
    private final static String QUEUE_NAME = "hello";

    public static void main(String[] args) throws Exception {
        // Utworzenie połączenia i kanału do komunikacji
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // Deklaracja kolejki do komunikacji
        channel.queueDeclare(QUEUE_NAME, false, false, false, null);

        // Wysyłanie wiadomości
        for (int i = 0; i < 20; i++) {
            String message = "Wiadomość #" + i;
            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
            System.out.println("Wysłano: " + message);
            Thread.sleep(500); // Czekaj 0.5 sekundy między wiadomościami
        }

        // Zamknięcie kanału i połączenia
        channel.close();
        connection.close();
    }
}