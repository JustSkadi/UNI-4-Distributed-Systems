package org.example.jaxws.server_topdown;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.List;

@WebService(serviceName = "PersonService",
        endpointInterface = "org.example.jaxws.server_topdown.PersonService")
public class PersonService2Impl implements PersonService {
    private List<Person> personList;

    public PersonService2Impl() {
        personList = new ArrayList<>();
        personList.add(createPerson(1, "Marius", 9));
        personList.add(createPerson(2, "Andrzej", 10));
    }

    private Person createPerson(int id, String name, int age) {
        Person person = new Person();
        person.setId(id);
        person.setFirstName(name);
        person.setAge(age);
        return person;
    }

    @Override
    public List<Person> getAllPersons() {
        System.out.println("called getAllPersons");
        return personList;
    }

    @Override
    public Person getPerson(int id) throws PersonNotFoundEx_Exception {
        System.out.println("called getPerson: " + id);
        for (Person thePerson : personList) {
            if (thePerson.getId() == id) {
                return thePerson;
            }
        }
        PersonNotFoundEx exception = new PersonNotFoundEx();
        exception.setMessage("The specified person does not exist");
        throw new PersonNotFoundEx_Exception("The specified person does not exist", exception);
    }

    @Override
    public Person addPerson(int id, String name, int age) throws PersonExistsEx_Exception {
        System.out.println("called addPerson: " + id + ", " + name + ", " + age);
        for (Person thePerson : personList) {
            if (thePerson.getId() == id) {
                PersonExistsEx exception = new PersonExistsEx();
                exception.setMessage("This person already exists");
                throw new PersonExistsEx_Exception("This person already exists", exception);
            }
        }
        Person person = createPerson(id, name, age);
        personList.add(person);
        return person;
    }

    @Override
    public boolean deletePerson(int id) throws PersonNotFoundEx_Exception {
        System.out.println("called deletePerson: " + id);
        for (int i = 0; i < personList.size(); i++) {
            if (personList.get(i).getId() == id) {
                personList.remove(i);
                return true;
            }
        }
        PersonNotFoundEx exception = new PersonNotFoundEx();
        exception.setMessage("The specified person does not exist");
        throw new PersonNotFoundEx_Exception("The specified person does not exist", exception);
    }

    @Override
    public int countPersons() {
        System.out.println("called countPersons");
        return personList.size();
    }
}