package org.example.jaxws.server;

import javax.xml.ws.WebFault;

@WebFault
public class PersonExistsEx extends Exception {
    public PersonExistsEx() {
        super("This person already exists");
    }
}