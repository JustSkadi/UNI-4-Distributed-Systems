package org.example.jaxws.server;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

@WebService
public interface PersonService {
    @WebMethod
    List<Person> getAllPersons();

    @WebMethod
    Person getPerson(@WebParam(name="id") int id) throws PersonNotFoundEx;

    @WebMethod
    Person addPerson(@WebParam(name="id") int id,
                     @WebParam(name="name") String name,
                     @WebParam(name="age") int age) throws PersonExistsEx;

    @WebMethod
    boolean deletePerson(@WebParam(name="id") int id) throws PersonNotFoundEx;

    @WebMethod
    int countPersons();
}