@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.jaxws.example.org/")
package org.example.jaxws.server_topdown;
