package org.example.jaxws.server;

import javax.jws.WebService;
import java.util.List;

@WebService(serviceName = "PersonService",
        endpointInterface = "org.example.jaxws.server.PersonService")
public class PersonServiceImpl implements PersonService {
    private PersonRepository dataRepository = new PersonRepositoryImpl();

    @Override
    public List<Person> getAllPersons() {
        System.out.println("called getAllPersons");
        return dataRepository.getAllPersons();
    }

    @Override
    public Person getPerson(int id) throws PersonNotFoundEx {
        System.out.println("called getPerson: " + id);
        return dataRepository.getPerson(id);
    }

    @Override
    public Person addPerson(int id, String name, int age) throws PersonExistsEx {
        System.out.println("called addPerson: " + id + ", " + name + ", " + age);
        return dataRepository.addPerson(id, name, age);
    }

    @Override
    public boolean deletePerson(int id) throws PersonNotFoundEx {
        System.out.println("called deletePerson: " + id);
        return dataRepository.deletePerson(id);
    }

    @Override
    public int countPersons() {
        System.out.println("called countPersons");
        return dataRepository.countPersons();
    }
}