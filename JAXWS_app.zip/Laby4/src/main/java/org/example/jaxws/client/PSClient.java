package org.example.jaxws.client;

import org.example.jaxws.server_topdown.*;
import javax.xml.namespace.QName;
import java.net.URL;

public class PSClient {
    public static void main(String[] args) throws Exception {
        URL url = new URL("http://localhost:8081/personservice?wsdl");
        PersonService_Service psService = new PersonService_Service(url);

        // Użyj właściwej nazwy portu (sprawdź w WSDL)
        PersonService psProxy = psService.getPort(
                new QName("http://server.jaxws.example.org/", "PersonServiceImplPort"),
                PersonService.class
        );

        // Wyświetl liczbę osób
        int num = psProxy.countPersons();
        System.out.println("Number of persons: " + num);

        // Wyświetl wszystkie osoby
        System.out.println("All persons:");
        for (Person p : psProxy.getAllPersons()) {
            System.out.println("Person: " + p.getId() + ", " + p.getFirstName() + ", age: " + p.getAge());
        }

        // Dodaj nową osobę
        try {
            Person newPerson = psProxy.addPerson(3, "Jan", 25);
            System.out.println("Added person: " + newPerson.getId() + ", " + newPerson.getFirstName());
        } catch (PersonExistsEx_Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Pobierz osobę po ID
        try {
            Person person = psProxy.getPerson(1);
            System.out.println("Got person: " + person.getId() + ", " + person.getFirstName());
        } catch (PersonNotFoundEx_Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Usuń osobę
        try {
            boolean deleted = psProxy.deletePerson(2);
            System.out.println("Person deleted: " + deleted);
        } catch (PersonNotFoundEx_Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Wyświetl zaktualizowaną liczbę osób
        num = psProxy.countPersons();
        System.out.println("Number of persons after operations: " + num);
    }
}