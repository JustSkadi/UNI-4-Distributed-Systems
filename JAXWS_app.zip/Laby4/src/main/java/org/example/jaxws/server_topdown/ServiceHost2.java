package org.example.jaxws.server_topdown;

import javax.xml.ws.Endpoint;

public class ServiceHost2 {
    public static void main(String[] args) {
        System.out.println("Web Service PersonService (Top-Down) is running ...");
        PersonService2Impl psi = new PersonService2Impl();
        Endpoint.publish("http://localhost:8082/personservice", psi);
        System.out.println("Press ENTER to STOP PersonService ...");
        try {
            System.in.read();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
}